export interface User {
  id: string;
  name: string;
  avatar: string;
  statusMessage?: string;
  isOfficial?: boolean;
  isOnline?: boolean;
  lastSeen?: string;
}

export type MessageType = 'text' | 'sticker' | 'image' | 'video' | 'voice' | 'system';

export interface Message {
  id: string;
  roomId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  type: MessageType;
  content: string; // text, sticker URL/id, image URL, or audio URL
  timestamp: string; // ISO string or format
  readBy: string[]; // User IDs who have read this
  meta?: {
    duration?: number; // for voice
    fileName?: string;
    stickerCategory?: string;
  };
}

export interface ChatRoom {
  id: string;
  name: string;
  avatar: string;
  isGroup: boolean;
  members: User[];
  lastMessage?: Message;
  unreadCount: number;
  updatedAt: string;
  pinned?: boolean;
}

export interface Sticker {
  id: string;
  category: string;
  name: string;
  emoji: string;
  imageUrl: string;
}

export interface MusicItem {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration: number; // in seconds
  url: string; // Blob URL, Data URL, or remote URL
  coverUrl?: string;
  format: string; // 'mp3' | 'mp4' | 'm4a' | 'flac' | string
  fileSize?: string;
  createdAt: string;
}

export type TabType = 'home' | 'chats' | 'album' | 'music' | 'settings';

export interface CallState {
  isActive: boolean;
  roomId: string;
  contactName: string;
  contactAvatar: string;
  type: 'voice' | 'video';
  status: 'ringing' | 'connected' | 'ended';
  duration: number;
}

export type WSMessageType =
  | 'init'
  | 'join_room'
  | 'send_message'
  | 'new_message'
  | 'typing'
  | 'read_messages'
  | 'presence'
  | 'create_room'
  | 'user_update';

export interface WSMessagePayload {
  type: WSMessageType;
  userId?: string;
  roomId?: string;
  message?: Message;
  user?: User;
  room?: ChatRoom;
  isTyping?: boolean;
  readMessageIds?: string[];
  onlineUsers?: string[];
}
