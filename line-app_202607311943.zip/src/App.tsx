import React, { useState, useEffect } from 'react';
import { User, ChatRoom, Message, TabType, CallState, WSMessagePayload } from './types';
import { wsService } from './services/websocket';
import { SmartphoneFrame } from './components/SmartphoneFrame';
import { HomeTab } from './components/HomeTab';
import { ChatsTab } from './components/ChatsTab';
import { ChatRoom as ChatRoomComponent } from './components/ChatRoom';
import { SettingsTab } from './components/SettingsTab';
import { AlbumTab } from './components/AlbumTab';
import { MusicTab } from './components/MusicTab';
import { LockScreen } from './components/LockScreen';
import { UnauthenticatedGuard } from './components/UnauthenticatedGuard';
import { ModalsContainer } from './components/ModalsContainer';
import { Home, MessageSquare, Images, Music, Settings as SettingsIcon } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('chats');
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);

  const [users, setUsers] = useState<User[]>([]);
  const [rooms, setRooms] = useState<ChatRoom[]>([]);
  const [roomMessages, setRoomMessages] = useState<Record<string, Message[]>>({});
  const [partnerTyping, setPartnerTyping] = useState<Record<string, boolean>>({});

  const [isNewChatModalOpen, setIsNewChatModalOpen] = useState(false);
  const [callState, setCallState] = useState<CallState | null>(null);

  // Account & Auth state
  const [authModalState, setAuthModalState] = useState<{
    isOpen: boolean;
    mode: 'login' | 'register' | 'forgot';
  }>({ isOpen: false, mode: 'login' });

  const [account, setAccount] = useState<{ id: string; name: string; email: string } | null>(() => {
    try {
      const saved = localStorage.getItem('line_app_account');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  // Screen lock state
  const [isAppLocked, setIsAppLocked] = useState(false);

  // Lock screen when page/tab is hidden
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && account) {
        setIsAppLocked(true);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [account]);

  const [activeUserId, setActiveUserId] = useState<string>(() => account?.id || 'user-me');

  const me: User = users.find((u) => u.id === activeUserId) || {
    id: activeUserId,
    name: account?.name || 'あなた',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    statusMessage: 'プログラミング勉強中 💻',
    isOnline: true,
  };

  const handleAuthSuccess = (user: User, accountInfo?: { id: string; name: string; email: string }) => {
    if (accountInfo) {
      setAccount(accountInfo);
      localStorage.setItem('line_app_account', JSON.stringify(accountInfo));
    }
    setActiveUserId(user.id);
    setIsAppLocked(false);
    fetchData();
  };

  const handleLogout = () => {
    setAccount(null);
    localStorage.removeItem('line_app_account');
    setActiveUserId('user-me');
    setIsAppLocked(false);
  };

  // 1. Initial REST fetch
  const fetchData = async () => {
    try {
      const [usersRes, roomsRes] = await Promise.all([
        fetch('/api/users').then((r) => r.json()),
        fetch('/api/rooms').then((r) => r.json()),
      ]);

      setUsers(usersRes);
      setRooms(roomsRes);

      // Fetch messages for initial rooms
      for (const room of roomsRes) {
        fetch(`/api/rooms/${room.id}/messages`)
          .then((r) => r.json())
          .then((msgs) => {
            setRoomMessages((prev) => ({ ...prev, [room.id]: msgs }));
          });
      }
    } catch (err) {
      console.error('Error fetching initial REST data:', err);
    }
  };

  useEffect(() => {
    fetchData();

    // Connect WebSocket
    wsService.connect();

    // WebSocket Event Listener
    const unsubscribe = wsService.subscribe((payload: WSMessagePayload) => {
      setIsConnected(true);

      if (payload.type === 'init') {
        if (payload.onlineUsers) {
          setUsers((prev) =>
            prev.map((u) => ({ ...u, isOnline: payload.onlineUsers?.includes(u.id) }))
          );
        }
      } else if (payload.type === 'new_message' && payload.message) {
        const msg = payload.message;
        setRoomMessages((prev) => {
          const existing = prev[msg.roomId] || [];
          if (existing.some((m) => m.id === msg.id)) return prev;
          return { ...prev, [msg.roomId]: [...existing, msg] };
        });

        // Update room lastMessage and unread count
        setRooms((prev) =>
          prev.map((r) => {
            if (r.id === msg.roomId) {
              const isCurrentOpenRoom = activeRoomId === msg.roomId;
              return {
                ...r,
                lastMessage: msg,
                updatedAt: msg.timestamp,
                unreadCount: isCurrentOpenRoom ? 0 : r.unreadCount + (msg.senderId !== me.id ? 1 : 0),
              };
            }
            return r;
          })
        );
      } else if (payload.type === 'typing' && payload.roomId) {
        setPartnerTyping((prev) => ({
          ...prev,
          [payload.roomId!]: !!payload.isTyping,
        }));
      } else if (payload.type === 'read_messages' && payload.roomId) {
        setRoomMessages((prev) => {
          const roomMsgs = prev[payload.roomId!] || [];
          return {
            ...prev,
            [payload.roomId!]: roomMsgs.map((m) => {
              if (!m.readBy.includes(payload.userId!)) {
                return { ...m, readBy: [...m.readBy, payload.userId!] };
              }
              return m;
            }),
          };
        });
      } else if (payload.type === 'create_room' && payload.room) {
        const newRoom = payload.room;
        setRooms((prev) => [newRoom, ...prev]);
      }
    });

    return () => {
      unsubscribe();
    };
  }, [activeRoomId]);

  // Open Chat Room
  const handleOpenChat = (roomId: string) => {
    setActiveRoomId(roomId);

    // Reset unread count
    setRooms((prev) =>
      prev.map((r) => (r.id === roomId ? { ...r, unreadCount: 0 } : r))
    );

    // Send read status event
    wsService.send({
      type: 'read_messages',
      roomId,
      userId: me.id,
    });
  };

  // Send Message
  const handleSendMessage = (type: Message['type'], content: string, meta?: any) => {
    if (!activeRoomId) return;

    const newMsg: Message = {
      id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      roomId: activeRoomId,
      senderId: me.id,
      senderName: me.name,
      senderAvatar: me.avatar,
      type,
      content,
      timestamp: new Date().toISOString(),
      readBy: [me.id],
      meta,
    };

    // Optimistic UI update
    setRoomMessages((prev) => ({
      ...prev,
      [activeRoomId]: [...(prev[activeRoomId] || []), newMsg],
    }));

    setRooms((prev) =>
      prev.map((r) =>
        r.id === activeRoomId ? { ...r, lastMessage: newMsg, updatedAt: newMsg.timestamp } : r
      )
    );

    // Send via WebSocket
    wsService.send({
      type: 'send_message',
      message: newMsg,
    });
  };

  // Typing status emit
  const handleSendTypingStatus = (isTyping: boolean) => {
    if (!activeRoomId) return;
    wsService.send({
      type: 'typing',
      roomId: activeRoomId,
      userId: me.id,
      isTyping,
    });
  };

  // Add Friend
  const handleAddFriend = async (friendId: string) => {
    try {
      const res = await fetch('/api/users/add-friend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: me.id, friendId }),
      });
      if (res.ok) {
        fetchData();
      }
    } catch (err) {
      console.error('Error adding friend:', err);
    }
  };

  // Create Room
  const handleCreateRoom = async (name: string, memberIds: string[], isGroup: boolean) => {
    try {
      // Auto add members as friends if not already
      for (const mId of memberIds) {
        if (!me.friendIds?.includes(mId)) {
          await handleAddFriend(mId);
        }
      }

      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, memberIds, isGroup }),
      });
      const room: ChatRoom = await res.json();
      setRooms((prev) => [room, ...prev]);
      handleOpenChat(room.id);
    } catch (err) {
      console.error('Error creating room:', err);
    }
  };

  // Update Profile
  const handleUpdateProfile = async (name: string, statusMessage: string, avatar: string) => {
    try {
      const res = await fetch('/api/users/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, statusMessage, avatar }),
      });
      const updatedUser: User = await res.json();
      setUsers((prev) => prev.map((u) => (u.id === me.id ? updatedUser : u)));
    } catch (err) {
      console.error('Error updating profile:', err);
    }
  };

  // Reset Database
  const handleResetDatabase = async () => {
    try {
      await fetch('/api/seed/reset', { method: 'POST' });
      fetchData();
    } catch (err) {
      console.error('Error resetting database:', err);
    }
  };

  // Start Call
  const handleStartCall = (type: 'voice' | 'video') => {
    const currentRoom = rooms.find((r) => r.id === activeRoomId);
    if (!currentRoom) return;

    setCallState({
      isActive: true,
      roomId: currentRoom.id,
      contactName: currentRoom.name,
      contactAvatar: currentRoom.avatar,
      type,
      status: 'connected',
      duration: 0,
    });
  };

  // Total unread messages across all rooms
  const totalUnread = rooms.reduce((acc, r) => acc + (r.unreadCount || 0), 0);
  const currentRoom = rooms.find((r) => r.id === activeRoomId);

  return (
    <SmartphoneFrame isConnected={isConnected}>
      {!account ? (
        /* 未ログイン時のガード画面 */
        <UnauthenticatedGuard
          onOpenAuthModal={(mode) => setAuthModalState({ isOpen: true, mode })}
        />
      ) : isAppLocked ? (
        /* 画面ロック時のパスワード解除画面 */
        <LockScreen
          user={me}
          account={account}
          onUnlock={() => setIsAppLocked(false)}
          onLogout={handleLogout}
        />
      ) : activeRoomId && currentRoom ? (
        /* If Chat Room is Active, render full ChatRoom */
        <ChatRoomComponent
          room={currentRoom}
          currentUser={me}
          messages={roomMessages[activeRoomId] || []}
          onSendMessage={handleSendMessage}
          onBack={() => setActiveRoomId(null)}
          onStartCall={handleStartCall}
          isPartnerTyping={partnerTyping[activeRoomId] || false}
          onSendTypingStatus={handleSendTypingStatus}
          onOpenAlbums={() => {
            setActiveRoomId(null);
            setActiveTab('album');
          }}
        />
      ) : (
        /* Tab Views */
        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
          {activeTab === 'home' && (
            <HomeTab
              currentUser={me}
              users={users}
              rooms={rooms}
              onOpenChat={handleOpenChat}
              onOpenNewChatModal={() => setIsNewChatModalOpen(true)}
              onOpenProfileSettings={() => setActiveTab('settings')}
              isLoggedIn={!!account}
              onOpenAuthModal={(mode = 'login') =>
                setAuthModalState({ isOpen: true, mode })
              }
              onAddFriend={handleAddFriend}
            />
          )}

          {activeTab === 'chats' && (
            <ChatsTab
              rooms={rooms}
              currentUser={me}
              onOpenChat={handleOpenChat}
              onOpenNewChatModal={() => setIsNewChatModalOpen(true)}
            />
          )}

          {activeTab === 'album' && (
            <AlbumTab
              isLoggedIn={!!account}
              onOpenAuthModal={() => setAuthModalState({ isOpen: true, mode: 'login' })}
            />
          )}

          {activeTab === 'music' && (
            <MusicTab
              isLoggedIn={!!account}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsTab
              currentUser={me}
              accountEmail={account?.email}
              onUpdateProfile={handleUpdateProfile}
              onResetDatabase={handleResetDatabase}
              onOpenAuthModal={(mode = 'login') =>
                setAuthModalState({ isOpen: true, mode })
              }
              onLogout={handleLogout}
              onLockApp={() => setIsAppLocked(true)}
              isConnected={isConnected}
            />
          )}

          {/* Bottom Tab Bar Navigation */}
          <nav className="bg-white border-t border-slate-200/80 px-2 py-2 flex items-center justify-around z-30 shadow-lg">
            <button
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center gap-1 flex-1 py-1 transition ${
                activeTab === 'home' ? 'text-[#00c300] font-bold' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Home className="w-5 h-5" />
              <span className="text-[10px]">ホーム</span>
            </button>

            <button
              onClick={() => setActiveTab('chats')}
              className={`flex flex-col items-center gap-1 flex-1 py-1 transition relative ${
                activeTab === 'chats' ? 'text-[#00c300] font-bold' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <div className="relative">
                <MessageSquare className="w-5 h-5" />
                {totalUnread > 0 && (
                  <span className="absolute -top-1.5 -right-2 min-w-[16px] h-[16px] px-1 bg-[#00c300] text-white text-[9px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                    {totalUnread > 99 ? '99+' : totalUnread}
                  </span>
                )}
              </div>
              <span className="text-[10px]">トーク</span>
            </button>

            <button
              onClick={() => setActiveTab('album')}
              className={`flex flex-col items-center gap-1 flex-1 py-1 transition ${
                activeTab === 'album' ? 'text-[#00c300] font-bold' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Images className="w-5 h-5" />
              <span className="text-[10px]">アルバム</span>
            </button>

            <button
              onClick={() => setActiveTab('music')}
              className={`flex flex-col items-center gap-1 flex-1 py-1 transition ${
                activeTab === 'music' ? 'text-[#00c300] font-bold' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <Music className="w-5 h-5" />
              <span className="text-[10px]">音楽</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`flex flex-col items-center gap-1 flex-1 py-1 transition ${
                activeTab === 'settings' ? 'text-emerald-600 font-bold' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <SettingsIcon className="w-5 h-5" />
              <span className="text-[10px]">設定</span>
            </button>
          </nav>
        </div>
      )}

      {/* Modals & Overlays Container */}
      <ModalsContainer
        isNewChatModalOpen={isNewChatModalOpen}
        users={users}
        currentUser={me}
        onCloseNewChatModal={() => setIsNewChatModalOpen(false)}
        onCreateRoom={handleCreateRoom}
        callState={callState}
        onEndCall={() => setCallState(null)}
        authModalState={authModalState}
        onCloseAuthModal={() => setAuthModalState((prev) => ({ ...prev, isOpen: false }))}
        onAuthSuccess={handleAuthSuccess}
      />
    </SmartphoneFrame>
  );
}
